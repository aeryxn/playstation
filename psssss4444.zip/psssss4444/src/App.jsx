import React, { useEffect, useState } from "react";
import "./App.css";

function displayTime(type) {
	var dateTime = new Date();
	var hrs = dateTime.getHours();
	var min = dateTime.getMinutes();
	var sec = dateTime.getSeconds();

	if (hrs >= 12) {
		let session = "PM";
	} else {
		let session = "AM";
	}

	if (hrs > 12) {
		hrs = hrs - 12;
	}

	if (type === "hour") {
		return hrs;
	} else if (type === "minutes") {
		return min;
	} else if (type === "session") {
		return session;
	}
}

function App() {
	const [Login, setLogin] = useState(false);
	const [state, setState] = useState(0);
	const [showText, setShowText] = useState(0);

	const classChanger = (id, img, textPhase, gameName) => {
		let selected = (
			<div className="div">
				<div
					className="menuItem2"
					id={id}
					onMouseOver={() => {
						setShowText(textPhase);
					}}
					onMouseLeave={() => {
						setShowText(0);
					}}
				>
					<img className="iconImg" src={img}></img>
					{showText === textPhase && <h1 className="iconText">Start</h1>}
				</div>
				{showText === textPhase && <h1 className="gameName">{gameName}</h1>}
			</div>
		);
		return selected;
	};

	return (
		<>
			{state === 0 && (
				<div id="loginScreen" style={{ opacity: Login ? "0" : "1" }}>
					<div className="logo">
						<img className="ps4" src="/playstation-4-logos-in-vector-format-png-0.png"></img>
					</div>
					<div
						className="lockscreen"
						onClick={() => {
							setLogin(true);
							setTimeout(() => {
								setState(state + 1);
							}, 1000);
						}}
					>
						<div id="lockItem1" className="lockItems">
							<img src="/plus-icon-plus-svg-png-icon-download-1.png" className="lockImg"></img>
							<h1 className="lockText">New User</h1>
						</div>
						<div id="lockItem2" className="lockItems">
							<img src="/1815e145596595f98723eca4fee59279.png" className="lockImg"></img>
							<h1 className="lockText">Player 1</h1>
						</div>
					</div>
				</div>
			)}
			{state === 1 && (
				<div>
					<div className="topMenu">
						<div id="psPlus" className="topItem">
							<div className="clock">
								<span id="hours">{setInterval(displayTime("hour"), 10)}</span>
								<span>:</span>
								<span id="minutes">00</span>
								<span id="session">AM</span>
							</div>
							<img id="settingsLogo" src="/playstation-plus-logo-5DBDF15160-seeklogo.com.png"></img>
						</div>
					</div>
					<div className="gameMenu">
						{classChanger("psStore", "/playstation_store_logo_1.webp", 1, "PS Store")}
						{classChanger("fortnite", "/download.jfif", 3, "Fortnite")}
						{classChanger("Spiderman2", "/public/spiderman23.png", 4, "Spider-Man")}
					</div>
				</div>
			)}
		</>
	);
}

export default App;
