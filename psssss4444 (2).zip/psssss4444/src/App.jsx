import React, { useEffect, useState } from "react";
import "./App.css";
import formatDate from "./formatDate";

function App() {
	const [Login, setLogin] = useState(false);
	const [state, setState] = useState(0);
	const [showText, setShowText] = useState(0);
	const [clockTime, setClockTime] = useState(formatDate(new Date().toLocaleTimeString()));

	setInterval(() => {
		setClockTime(formatDate(new Date().toLocaleTimeString()));
	});
	let back = false;

	const classChanger = (id, img, textPhase, nameImg, backgroundImage) => {
		let selected = (
			<div className="div">
				<div
					className="menuItem2"
					id={id}
					onMouseOver={() => {
						setShowText(textPhase);
						document.querySelector("body").style.backgroundImage = `url(${backgroundImage})`;
						// document.querySelector(`#${id}`).style.width = `17em`;
						// document.querySelector(`#${id}`).style.height = `17em`;
					}}
					// onMouseLeave={() => {
					// 	setShowText(0);
					// }}
					onClick={() => {
						back = true;
					}}
				>
					<img className="iconImg" src={img}></img>
				</div>
				{showText === textPhase && <img className="iconText" src={nameImg} />}
				{/* {showText === textPhase && <h1 className="iconButton">Play</h1>} */}
			</div>
		);
		return selected;
	};
	return (
		<>
			{state === 0 && (
				<div id="loginScreen" style={{ opacity: Login ? "0" : "1" }}>
					<div
						className="lockscreen"
						onClick={() => {
							setLogin(true);
							setTimeout(() => {
								setState(state + 1);
							}, 1000);
						}}
					>
						<div id="lockItem1" className="lockItems">
							<img src="/plusButton.png" className="lockImg"></img>
							<h1 className="lockText">New User</h1>
						</div>
						<div id="lockItem2" className="lockItems">
							<img src="/spidey.JPG" className="lockImg"></img>
							<h1 className="lockText">Player 1</h1>
						</div>
					</div>
				</div>
			)}
			{state === 1 && (
				<div>
					<div className="topMenu">
						<div id="clock" className="topItem">
							{clockTime}
						</div>
					</div>
					<div className="gameMenu">
						{classChanger("Spiderman2", "/spiderman23.png", 1, "/spidermantext-removebg-preview.png", "/spiderman2.png")}
						{classChanger("Miles", "/miles.png", 2, "/milestext3.png", "/milesmorales.jpg")}
						{classChanger("fortnite", "/download.jfif", 3, "/dortnitetext2.png", "/fortnite-wallie.jpg")}
					</div>
				</div>
			)}
		</>
	);
}

export default App;
