function formatDate(date) {
	const dateArr = date.split(":");
	const secs = dateArr[dateArr.length - 1].split(" ");

	dateArr.pop();

	dateArr.push(secs[1]);

	return `${dateArr[0]}:${dateArr[1]} ${dateArr[2]}`;
}
export default formatDate;
